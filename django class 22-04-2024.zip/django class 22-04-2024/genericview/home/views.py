from django.shortcuts import render
from django.views.generic.edit import * 
from django.views.generic.list import ListView
from .models import Student

class index(CreateView):
    model=Student 
    fields=['roll','name','contact']
    success_url='read'

class read(ListView):
    model=Student

class edit(UpdateView):
    model=Student 
    fields=['roll','name','contact']
    success_url='/read'

class delete(DeleteView):
    model=Student
    success_url='/read'

    




